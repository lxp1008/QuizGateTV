# 答题守门员 · Android TV(雷鸟 / FFALCON)版

把「每 10 分钟弹一道题、答对才继续」的网页,打包成一个能装进 TCL 雷鸟电视的 App。
本目录是**完整可构建的 Android 工程源码**——你在电脑上用 Android Studio 一键 Build 出 APK,再拷进 U 盘装到电视即可。

---

## 一、这个 App 能做什么、不能做什么(务必先看)

**能做**
- 在电视上全屏运行一个「计时 + 答题」应用:倒计时到 0 会持续响铃并弹题,**必须答对**才继续下一个 10 分钟。
- 适配遥控器:方向键移动焦点,OK/确认键作答,蓝色高亮框表示当前选中项。
- 屏幕常亮,不会自动息屏打断计时。

**做不到(重要)**
- 它**无法自动打断/暂停电视上其它 App(腾讯视频、爱奇艺、电视台等)的画面**。
  安卓系统不允许一个 App 强行盖住另一个 App 的视频。
- 所以现实用法是:把它当成电视上的一个「守门员」应用。约定好——
  **看视频前先打开它计时;它响铃弹题时,家长/孩子切回来答对,再切回视频。**
- 想做到「答不对电视真的黑屏」,只能走硬件方案(智能插座断电 / HDMI-CEC 盒子),不是装 App 能实现的。

---

## ⭐ 推荐方式:GitHub 云端自动构建 APK(免装 Android Studio)

你不需要在电脑上装任何安卓开发工具。GitHub 会在云端把本工程编译成一个**可直接安装的成品 APK**。

### 1. 注册 / 登录 GitHub
- 打开 https://github.com 注册一个免费账号(已有可跳过)。

### 2. 新建一个仓库
- 登录后点右上角 `+` → `New repository`。
- Repository name 填 `QuizGateTV`;选 **Public(公开)**(公开仓库的自动构建完全免费)。
- 不要勾选任何初始化选项(README/gitignore 都不勾),点 `Create repository`。

### 3. 把本工程文件上传上去
- 在新仓库页面点蓝字链接 **uploading an existing file**(或 `Add file` → `Upload files`)。
- 打开本文件夹 `QuizGateTV`,把里面的**所有内容**拖进上传区:
  `.github`、`app`、`gradle`、`build.gradle`、`settings.gradle`、`gradle.properties`、`README.md`、`.gitignore`。
  - ⚠️ 要拖文件夹**里面的东西**,不要把外层 `QuizGateTV` 文件夹整个拖进去,否则目录会多套一层导致构建失败。
  - 必须包含 `.github` 文件夹(云端构建脚本在里面)。
- 拖完后页面下方点 `Commit changes` 提交。

> 如果网页不让拖文件夹,可改用 GitHub Desktop(免费)把整个 `QuizGateTV` 发布上去,或请懂 git 的朋友 `git push` 一次即可。

### 4. 等云端自动构建
- 提交后点仓库顶部的 **Actions** 标签,会看到一条 `Build APK` 正在运行(黄色转圈)。
- 等 3–6 分钟变成绿色 ✔ 即成功,点进这条记录。

### 5. 下载现成的 APK
- 在记录页面最下方 **Artifacts** 区,点 `QuizGateTV-APK` 下载一个 zip。
- 解压得到 `app-debug.apk`——这就是**可直接安装的成品 APK**(已自带签名)。
- 建议重命名为 `QuizGateTV.apk`,拷进 U 盘,按下面「把 APK 装进雷鸟电视」安装即可。

---

## 备选方式:在电脑上用 Android Studio 构建 APK

### 1. 安装 Android Studio
- 下载:https://developer.android.com/studio (国内可用镜像 https://developer.android.google.cn/studio )
- 安装后首次启动,按向导下载 **Android SDK**(勾选 API 34 即可)。

### 2. 打开本工程
- Android Studio → `Open` → 选择本文件夹 `QuizGateTV`。
- 若弹出提示缺少 Gradle Wrapper(本工程未附带 `gradle-wrapper.jar`),选
  **“Use Gradle from: gradle-wrapper.properties”** 或允许 Android Studio 自动生成/下载,等待右下角 Sync 完成。
- Sync 成功后,左侧能正常展开 `app/src/main`。

### 3. 构建 APK
- 菜单:`Build` → `Build App Bundle(s) / APK(s)` → `Build APK(s)`。
- 等待完成,右下角弹窗点 **locate**,APK 路径通常为:
  `app/build/outputs/apk/debug/app-debug.apk`
- 这个 debug APK 已自带签名,**可直接侧载安装**(不是上架用的正式签名,自用足够)。

> 命令行方式(可选):在项目根目录执行 `gradlew.bat assembleDebug`(Windows)或 `./gradlew assembleDebug`(Mac/Linux)。

---

## 三、把 APK 装进雷鸟 / FFALCON 电视

方法 A(最常用:U 盘)
1. 把 `app-debug.apk` 拷到 U 盘(可重命名为 `QuizGateTV.apk` 方便识别)。
2. U 盘插到电视的 USB 口。
3. 电视上打开 **「媒体中心」/「我的应用」/「文件管理」**(不同雷鸟版本名字略有差异),找到 U 盘里的 APK。
4. 点击安装。若提示「禁止安装未知来源应用」,按提示进入
   **设置 → 安全/通用 → 允许安装未知来源应用**,打开后返回再装。
5. 装好后在电视「我的应用」里就能看到 **答题守门员**,用遥控器打开即可。

方法 B(局域网 / ADB,进阶)
- 若电视和本机在同一 WiFi,可开启电视的「ADB 调试/开发者模式」,用
  `adb connect <电视IP>` 然后 `adb install app-debug.apk` 安装。
- 雷鸟部分机型需要在「设置 → 关于 → 连续点击版本号」进入开发者选项后打开 USB/网络调试。

方法 C(免装 App 的替代)
- 如果不想折腾 APK,也可以把这个 HTML 发布成一个网址,用电视自带浏览器打开——
  但电视浏览器体验参差,且同样无法打断其它 App。**综合下来,U 盘装 APK 是效果最好的软件方案。**

---

## 四、遥控器操作说明

- 方向键(↑↓←→):在按钮/选项间移动,蓝框是当前焦点。
- OK / 确认键:点击选中的按钮或作答。
- 弹出题目时会自动聚焦第一个选项,直接按方向键选择、OK 确认。
- 右上角 ⛶(全屏)在 App 里默认已全屏;⚙️ 是家长设置(需先算一道乘法题才能改间隔)。

---

## 五、目录结构

```
QuizGateTV/
├─ settings.gradle            工程配置
├─ build.gradle               根构建脚本(AGP 8.5.2)
├─ gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties   (Gradle 8.7)
└─ app/
   ├─ build.gradle            应用构建脚本(compileSdk 34 / minSdk 21)
   └─ src/main/
      ├─ AndroidManifest.xml  声明 leanback + 全屏 + 横屏
      ├─ java/com/family/quizgate/MainActivity.java   WebView 壳
      ├─ assets/index.html    ★答题页面本体(题库和逻辑都在这里)
      └─ res/
         ├─ values/strings.xml
         └─ drawable/ic_launcher.xml, tv_banner.xml   图标与电视横幅
```

**想改题库或答题间隔?** 直接编辑 `app/src/main/assets/index.html`(顶部 `BANK` 数组是题库,
每题格式 `{c:"分类", q:"题干", o:["A","B","C","D"], a:正确项下标}`),改完重新 Build APK 即可。

---

## 六、常见问题

- **Sync 报错找不到 SDK / 版本**:确认已安装 API 34 的 SDK;或把 `app/build.gradle` 里的
  `compileSdk`、`targetSdk` 改成你已安装的版本(如 33)。
- **装到电视后是黑屏**:多为 WebView 版本过旧。雷鸟系统一般自带较新 WebView;
  若黑屏,尝试在电视「设置 → 应用」里更新 Android System WebView。
- **遥控器无法选中按钮**:确认用的是方向键而非触摸;页面按钮默认支持焦点导航。
- **声音不响**:检查电视音量;首次需要按一次 OK 键(用户手势)后音频才会解锁。
